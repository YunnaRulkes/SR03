package beans;

public class Parcours {

}
