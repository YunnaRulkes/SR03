package beans;

public class Question {

}
