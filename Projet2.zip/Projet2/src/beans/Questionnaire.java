package beans;

public class Questionnaire {

}
