package beans;

public class Reponse {

}
