
INSERT INTO UTILISATEUR(id, login, motDePasse, nom, prenom, email, statusAdmin) VALUES ('1', 'admin', '1234', 'Admin', 'Master', 'admin@admin.fr', true);
INSERT INTO UTILISATEUR(id, login, motDePasse, nom, prenom, email, statusAdmin) VALUES ('2', 'tmarinho', 'TMARINHO', 'Marinho', 'Thais', 'thais.marinho@etu.utc.fr', false);
INSERT INTO UTILISATEUR(id, login, motDePasse, nom, prenom, email, statusAdmin) VALUES ('3', 'fotsoloi', 'FOTSOLOI', 'Fotso', 'Loic', 'loic.fotso@etu.utc.fr', false);


