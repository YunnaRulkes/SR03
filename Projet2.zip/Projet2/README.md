
    It was utilized Java JDK+JRE 8, Tomcat 8.0.33, Eclipse Edition EE, mysql-client
    

